const Engine = require('./engine')
const { PantryView } = require('./view')

const canvas = wx.createCanvas()
const platform = {
  read(key) { try { return wx.getStorageSync(key) || 0 } catch (error) { return 0 } },
  write(key, value) { try { wx.setStorageSync(key, value) } catch (error) {} },
  vibrate() { wx.vibrateShort({ type: 'light', fail() {} }) }
}
const view = new PantryView(canvas, Engine, platform)
function resize() {
  const info = wx.getWindowInfo ? wx.getWindowInfo() : wx.getSystemInfoSync()
  view.resize(info.windowWidth, info.windowHeight, Math.min(info.pixelRatio || 2, 3))
}
resize()
wx.onTouchStart(e => { if (e.touches[0]) view.down(e.touches[0].clientX, e.touches[0].clientY) })
wx.onTouchMove(e => { if (e.touches[0]) view.move(e.touches[0].clientX, e.touches[0].clientY) })
wx.onTouchEnd(e => { if (e.changedTouches[0]) view.up(e.changedTouches[0].clientX, e.changedTouches[0].clientY) })
wx.onTouchCancel(() => view.cancel())
wx.onWindowResize(resize)
wx.onShow(() => { view.resume(); resize() })
wx.onHide(() => view.suspend())
wx.showShareMenu({ menus: ['shareAppMessage'] })
wx.onShareAppMessage(() => ({ title: '小仓鼠的零食柜快满了，来帮它收拾一下！' }))
