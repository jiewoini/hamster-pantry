(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory()
  else root.PantryView = factory()
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  const COLORS = ['#e9e2d7', '#e8a457', '#86aa8b', '#9c9bc7', '#dc8d80']
  const W = 375, H = 800, CELL = 43, BX = 37, BY = 222
  class PantryView {
    constructor(canvas, engine, platform) {
      this.canvas = canvas
      this.ctx = canvas.getContext('2d')
      this.engine = engine
      this.platform = platform
      this.state = 'home'
      this.mode = 'classic'
      this.selected = 0
      this.buttons = []
      this.effects = []
      this.message = ''
      this.messageUntil = 0
      this.pointer = null
      this.running = false
      this.game = new engine.Game(12345)
      this.resume()
    }
    resize(width, height, ratio = 1) {
      this.width = width; this.height = height; this.ratio = ratio
      this.canvas.width = Math.round(width * ratio)
      this.canvas.height = Math.round(height * ratio)
      this.scale = Math.min(width / W, height / H)
      this.offsetX = (width - W * this.scale) / 2
      this.offsetY = (height - H * this.scale) / 2
      this.render()
    }
    resume() {
      if (this.running) return
      this.running = true
      const tick = () => {
        if (!this.running) return
        if (this.scale) this.render()
        this.frame = typeof requestAnimationFrame === 'function' ? requestAnimationFrame(tick) : setTimeout(tick, 32)
      }
      tick()
    }
    suspend() {
      this.running = false
      if (typeof cancelAnimationFrame === 'function') cancelAnimationFrame(this.frame)
      else clearTimeout(this.frame)
      this.cancel()
      if (this.state === 'playing') this.state = 'paused'
    }
    key() { return this.mode === 'daily' ? `pantry_daily_${this.day}` : 'pantry_classic_v1' }
    start(mode) {
      this.mode = mode
      this.day = this.engine.dateKey()
      const seed = mode === 'daily' ? Number(this.day) : (Date.now() ^ Math.floor(Math.random() * 1000000)) >>> 0
      this.game = new this.engine.Game(seed)
      this.state = 'playing'; this.selected = 0; this.pointer = null; this.effects = []
      this.best = Number(this.platform.read(this.key())) || 0
      this.notify(mode === 'daily' ? '今天同一套方块，试着突破 800 分' : '选一块零食，再点柜子里的空位')
    }
    notify(message) { this.message = message; this.messageUntil = Date.now() + 2300 }
    point(x, y) { return { x: (x - this.offsetX) / this.scale, y: (y - this.offsetY) / this.scale } }
    inside(p, b) { return p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h }
    down(x, y) {
      const p = this.point(x, y)
      const button = this.buttons.slice().reverse().find(b => this.inside(p, b))
      if (button) { this.pressed = button; return }
      if (this.state !== 'playing') return
      if (p.y >= 554 && p.y <= 668) {
        const index = Math.floor((p.x - 24) / 109)
        if (index >= 0 && index < 3 && this.game.tray[index]) {
          this.selected = index
          this.pointer = { ...p, startX: p.x, startY: p.y, dragged: false }
        }
      } else if (p.x >= BX && p.x < BX + CELL * 7 && p.y >= BY && p.y < BY + CELL * 7) {
        this.pointer = { ...p, startX: p.x, startY: p.y, boardTap: true, dragged: false }
      }
    }
    move(x, y) {
      if (!this.pointer || this.state !== 'playing') return
      const p = this.point(x, y)
      if (Math.hypot(p.x - this.pointer.startX, p.y - this.pointer.startY) > 8) this.pointer.dragged = true
      Object.assign(this.pointer, p)
    }
    up(x, y) {
      const p = this.point(x, y)
      if (this.pressed) {
        const b = this.pressed; this.pressed = null
        if (this.inside(p, b)) b.action()
        return
      }
      if (this.state !== 'playing' || !this.pointer) return
      this.move(x, y)
      const pointer = this.pointer
      this.pointer = null
      if (!pointer.boardTap && !pointer.dragged) return
      const gx = Math.floor((p.x - BX) / CELL)
      const gy = Math.floor((p.y - (pointer.dragged && !pointer.boardTap ? 46 : 0) - BY) / CELL)
      const result = this.game.place(this.selected, gx, gy)
      if (!result) { this.notify('这里放不下，换个位置或旋转一下'); return }
      this.platform.write(this.key(), Math.max(this.best, this.game.score))
      this.best = Math.max(this.best, this.game.score)
      if (result.count) {
        this.platform.vibrate()
        this.notify(`${result.count > 1 ? '漂亮！' : '收好啦！'}清空 ${result.count} 条 · +${result.gained}`)
        this.effects = result.cleared.map(([cx, cy, color]) => ({ x: BX + cx * CELL + 21, y: BY + cy * CELL + 21, color, time: Date.now() }))
      }
      this.selected = this.game.tray.findIndex(Boolean)
      if (result.over) this.state = 'over'
    }
    cancel() { this.pointer = null; this.pressed = null }
    undo() {
      if (!this.game.undo()) { this.notify('放下一块后，就能撤回这一步'); return }
      this.selected = this.game.tray.findIndex(Boolean)
      this.state = 'playing'; this.effects = []; this.notify('已撤回上一步')
    }
    round(x, y, w, h, radius, color, stroke) {
      const c = this.ctx, r = Math.min(radius, w / 2, h / 2)
      c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r)
      c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath()
      if (color) { c.fillStyle = color; c.fill() }
      if (stroke) { c.strokeStyle = stroke; c.lineWidth = 2; c.stroke() }
    }
    text(text, x, y, size = 14, color = '#514a41', align = 'left', bold = false) {
      const c = this.ctx; c.fillStyle = color; c.font = `${bold ? 'bold ' : ''}${size}px "Microsoft YaHei", "PingFang SC", sans-serif`
      c.textAlign = align; c.textBaseline = 'middle'; c.fillText(String(text), x, y)
    }
    button(label, x, y, w, h, action, primary = false) {
      this.round(x, y, w, h, 17, primary ? '#657f5a' : '#fffdf8')
      this.text(label, x + w / 2, y + h / 2, 15, primary ? '#fff' : '#657356', 'center', true)
      this.buttons.push({ x, y, w, h, action })
    }
    hamster(x, y, size = 1) {
      const c = this.ctx; c.save(); c.translate(x, y); c.scale(size, size)
      const ellipse = (cx, cy, rx, ry, color) => { c.beginPath(); c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); c.fillStyle = color; c.fill() }
      ellipse(-23, -22, 15, 17, '#d4ab7d'); ellipse(23, -22, 15, 17, '#d4ab7d')
      ellipse(-23, -23, 8, 10, '#e9c4b6'); ellipse(23, -23, 8, 10, '#e9c4b6')
      ellipse(0, 3, 39, 35, '#d4ab7d'); ellipse(0, 15, 31, 23, '#fff1dc')
      ellipse(-13, 1, 3, 4, '#594335'); ellipse(13, 1, 3, 4, '#594335')
      ellipse(-23, 12, 7, 4, '#e9b3a2'); ellipse(23, 12, 7, 4, '#e9b3a2'); ellipse(0, 10, 3.5, 2.5, '#976a52')
      c.strokeStyle = '#976a52'; c.lineWidth = 1.5; c.beginPath(); c.moveTo(0, 12); c.lineTo(0, 17); c.stroke()
      c.restore()
    }
    block(x, y, size, color, alpha = 1) {
      const c = this.ctx; c.save(); c.globalAlpha = alpha
      this.round(x + 2, y + 3, size - 4, size - 4, 8, COLORS[color])
      this.round(x + 6, y + 6, size - 12, Math.max(3, size * .15), 3, 'rgba(255,255,255,.25)')
      c.restore()
    }
    drawBoard() {
      this.round(BX - 9, BY - 9, CELL * 7 + 18, CELL * 7 + 18, 22, '#ddd3c4')
      for (let y = 0; y < 7; y++) for (let x = 0; x < 7; x++) {
        this.round(BX + x * CELL + 2, BY + y * CELL + 3, CELL - 4, CELL - 4, 8, '#f6f1e8')
        if (this.game.board[y][x]) this.block(BX + x * CELL, BY + y * CELL, CELL, this.game.board[y][x])
      }
      const piece = this.game.tray[this.selected]
      if (this.pointer && piece && (this.pointer.dragged || this.pointer.boardTap)) {
        const x = Math.floor((this.pointer.x - BX) / CELL)
        const y = Math.floor((this.pointer.y - (!this.pointer.boardTap && this.pointer.dragged ? 46 : 0) - BY) / CELL)
        const valid = this.game.canPlace(piece.cells, x, y)
        piece.cells.forEach(([dx, dy]) => {
          if (x + dx >= 0 && x + dx < 7 && y + dy >= 0 && y + dy < 7) {
            this.round(BX + (x + dx) * CELL + 3, BY + (y + dy) * CELL + 4, CELL - 6, CELL - 6, 8, valid ? '#b6c6a0' : '#e6b3a6')
          }
        })
      }
      const now = Date.now()
      this.effects = this.effects.filter(p => now - p.time < 650)
      this.effects.forEach((p, index) => {
        const t = (now - p.time) / 650
        this.block(p.x - 10 + Math.sin(index * 3) * t * 25, p.y - 10 - t * 45, 20, p.color, 1 - t)
      })
    }
    drawTray() {
      for (let index = 0; index < 3; index++) {
        const x = 24 + index * 109, piece = this.game.tray[index]
        this.round(x, 554, 103, 110, 20, index === this.selected ? '#fffdf8' : '#eee9df', index === this.selected ? '#b5bf9d' : null)
        if (!piece) { this.text('已收好', x + 51, 610, 12, '#b1aa9d', 'center'); continue }
        const width = Math.max(...piece.cells.map(p => p[0])) + 1
        const height = Math.max(...piece.cells.map(p => p[1])) + 1
        const size = Math.min(25, 86 / width, 83 / height)
        piece.cells.forEach(([dx, dy]) => this.block(x + (103 - width * size) / 2 + dx * size, 554 + (110 - height * size) / 2 + dy * size, size, piece.color))
      }
    }
    render() {
      const c = this.ctx
      c.setTransform(this.ratio, 0, 0, this.ratio, 0, 0)
      c.fillStyle = '#f6f2e9'; c.fillRect(0, 0, this.width, this.height)
      c.translate(this.offsetX, this.offsetY); c.scale(this.scale, this.scale)
      this.buttons = []
      this.text('PANTRY CLUB', 27, 55, 10, '#969d82', 'left', true)
      this.text('小仓鼠囤囤', 25, 86, 30, '#454d38', 'left', true)
      this.text('把零碎，放整齐。', 27, 116, 13, '#9c9688')
      this.hamster(315, 108, .65)
      this.round(25, 144, 325, 56, 18, '#e9e8da')
      this.text('本局得分', 44, 162, 10, '#8d927d'); this.text(this.game.score, 44, 184, 22, '#536448', 'left', true)
      this.text(this.mode === 'daily' ? '今日个人最佳' : '个人最佳', 179, 162, 10, '#8d927d')
      this.text(this.best || 0, 179, 184, 22, '#536448', 'left', true)
      if (this.state === 'playing') {
        this.button('Ⅱ', 292, 150, 45, 43, () => { this.cancel(); this.state = 'paused' })
      }
      this.drawBoard()
      this.text('待收纳的零食', 27, 541, 11, '#9a9589')
      this.drawTray()
      this.button('旋转 ↻', 25, 687, 155, 46, () => {
        if (this.state !== 'playing') return
        this.game.rotate(this.selected); this.notify('换个方向，试试这个空位')
      })
      this.button('撤回一步', 195, 687, 155, 46, () => { if (this.state === 'playing') this.undo() })
      this.text(this.mode === 'daily' ? '每日同题 · 本地日期更新 · 自由旋转' : '填满整行或整列即可清空 · 方块可旋转', W / 2, 758, 11, '#9a9589', 'center')
      if (this.messageUntil > Date.now() && this.state === 'playing') {
        this.round(25, 742, 325, 32, 12, '#514e44')
        this.text(this.message, W / 2, 758, 12, '#fffdf8', 'center')
      }
      if (this.state !== 'playing') this.overlay()
    }
    overlay() {
      const c = this.ctx
      c.fillStyle = '#f6f2e9'; c.fillRect(0, 0, W, H)
      this.buttons = []
      this.hamster(W / 2, 204, 1.5)
      if (this.state === 'home') {
        this.text('小仓鼠囤囤', W / 2, 307, 35, '#454d38', 'center', true)
        this.text('一柜零食，一点小满足', W / 2, 348, 16, '#97917f', 'center')
        this.round(36, 389, 303, 102, 22, '#ebe8db')
        this.text('拖动方块，放进空格', W / 2, 419, 15, '#637057', 'center', true)
        this.text('填满整行或整列，就能腾出新空间', W / 2, 453, 12, '#96917f', 'center')
        this.button('开始收纳', 48, 527, 279, 57, () => this.start('classic'), true)
        this.button('每日同题 · 今日目标 800 分', 48, 600, 279, 51, () => this.start('daily'))
        this.text('不赶时间，给小仓鼠留一点空位', W / 2, 703, 12, '#a29b8e', 'center')
      } else if (this.state === 'paused') {
        this.text('歇一小会儿', W / 2, 310, 29, '#454d38', 'center', true)
        this.text('零食还在原处，随时回来', W / 2, 352, 14, '#96917f', 'center')
        this.button('继续收纳', 48, 421, 279, 55, () => { this.state = 'playing' }, true)
        this.button('重新开始这一局', 48, 494, 279, 51, () => this.start(this.mode))
        this.button('回到首页', 48, 567, 279, 51, () => { this.state = 'home' })
      } else {
        this.text('柜子装满啦', W / 2, 306, 29, '#454d38', 'center', true)
        this.text('这次收纳得分', W / 2, 350, 14, '#96917f', 'center')
        this.text(this.game.score, W / 2, 401, 53, '#657f5a', 'center', true)
        this.text(`清空 ${this.game.lines} 条 · 放好 ${this.game.moves} 块`, W / 2, 450, 14, '#96917f', 'center')
        this.button('再收一柜', 48, 501, 279, 55, () => this.start(this.mode), true)
        if (this.game.last) this.button('撤回最后一步再试试', 48, 573, 279, 51, () => this.undo())
        this.button('回到首页', 48, 644, 279, 49, () => { this.state = 'home' })
      }
    }
  }
  return { PantryView }
})
